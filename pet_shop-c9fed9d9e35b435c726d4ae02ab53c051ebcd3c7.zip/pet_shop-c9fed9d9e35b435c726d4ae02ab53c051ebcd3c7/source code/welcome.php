
<?php



// Grab User submitted information
$email = $_POST["username"];
$pass = $_POST["password"];

if($email=='pavan'&& $pass=='chikka1998')
echo "Connected successfully";
?>